# P1: The Cost of Natural Disasters

External sources:
- Tutorials 3 and 4
- D3 documentation
- GPT 5.2 for general debugging