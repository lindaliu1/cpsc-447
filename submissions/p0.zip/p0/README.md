# P0: Experiment Data

External sources: 
- Example code from tutorial 1 and 2
- D3 documentation
- Light debugging using GPT 4.1 to change grid line opacity and position data points in line with their respective trial numbers (y value)